import React from 'react'
import style from "./navbar.module.css"
const Advertise = () => {
  return (
    <div className={style.advertise}>
        <p>Extra 10% off on final Sale | use code: last call</p>
    </div>
  )
}

export default Advertise