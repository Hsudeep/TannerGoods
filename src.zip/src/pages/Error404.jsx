import React from 'react'

const Error404 = () => {
  return (
    <h1>Error$04</h1>
  )
}

export default Error404